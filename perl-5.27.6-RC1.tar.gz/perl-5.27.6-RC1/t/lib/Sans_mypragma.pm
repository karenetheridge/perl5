package Sans_mypragma;

sub affected {
    mypragma::in_effect();
}

1;
